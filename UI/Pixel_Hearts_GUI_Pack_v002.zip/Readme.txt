Pixel Hearts GUI Pack
Author snoblin.itch.io

License
You may use these assets in commercial and non-commercial projects.
You may edit theses assets.
You can't redistribute or resell theses assets, even if they have been modified.
Credits are optional but highly appreciated.

Thank you for downloading <3